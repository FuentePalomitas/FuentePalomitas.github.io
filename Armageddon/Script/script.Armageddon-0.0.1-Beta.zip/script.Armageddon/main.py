# By Hectobo
 

import base64, codecs
magic = 'ICAjc2NyaXB0LkFybWFnZWRkb24KIyAgIENvcHlyaWdodCAoQykgMjAxOSAgSGVjdG9ibwojCiMgICBUaGlzIHByb2dyYW0gaXMgZnJlZSBzb2Z0d2FyZTogeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeQojICAgaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnkKIyAgIHRoZ'
love = 'FOTpzIyVSAiMaE3LKWyVRMiqJ5xLKEco24fVTIcqTuypvO2MKWmnJ9hVQZto2LtqTuyVRkcL2Ihp2HfVT9lPvZtVPNbLKDtrJ91pvOipUEco24cVTShrFOfLKEypvO2MKWmnJ9hYtbwPvZtVPOHnTymVUOlo2qlLJ0tnKZtMTymqUWcLaI0MJDtnJ4tqTuyVTuipTHtqTuuqPOcqPO3nJkfVTWyVUImMJM1oPjXVlNtVTW1qPOKFIEVG1IHVRSBJFOKDIWFDH5HJGftq2y0nT'
god = '91dCBldmVuIHRoZSBpbXBsaWVkIHdhcnJhbnR5IG9mCiMgICBNRVJDSEFOVEFCSUxJVFkgb3IgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UuICBTZWUgdGhlCiMgICBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBmb3IgbW9yZSBkZXRhaWxzLgojCiMgICBZb3Ugc2hvdWxkIGhhdmUgcmVjZWl2ZWQgYSBjb3B5IG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJ'
destiny = 'fnJZtGTywMJ5mMDbwVPNtLJkiozptq2y0nPO0nTymVUOlo2qlLJ0hVPOWMvOho3DfVUAyMFN8nUE0pQbiY3q3ql5aoaHho3WaY2kcL2Ihp2ImYm4hPtbXnJ1jo3W0VUuvoJZfVUuvoJAuMTEiovjto3ZXPDxXrTWgLl5yrTIwqKEyLaIcoUEcovtaJRWADl5OL3EcqzS0MIqcozEiqluJnJEyo3ZfpTk1M2yhBv8ipTk1M2yhYaMcMTIiYxSloJSaMJExo24iXFpcPtbXPt=='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))